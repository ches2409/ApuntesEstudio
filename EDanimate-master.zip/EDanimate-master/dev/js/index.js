import {saludo, despedida} from "./modules/example";

saludo();
despedida();
