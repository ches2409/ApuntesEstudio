# EDui
EDui es una libreria de componentes UI para proyectos web

La idea es crear componentes reutilizables y que se puedan escoger solo los que se necesiten en cada proyecto.

En el primer commit se incluye

* Scroll animado
* Lightbox
* Sticky elements
* Tabs
* Funcion para crear cualquier ventana modal pasandole su contenido como parametro
* Ventana modal de YouTube
* Ventana modal de Vimeo

En proceso:

* Countdown
* Menus
* Botones
* Slider
* Tooltips
* Scrollspy menu
* mas...
